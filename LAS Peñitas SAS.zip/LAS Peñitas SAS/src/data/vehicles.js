const vehicles = [
  {
    name: "Misión",
    description: "Nuestra misión es proporcionar a nuestros clientes una experiencia excepcional en la compra y venta de automóviles y motocicletas. ",
    image:
      "https://thumbor.forbes.com/thumbor/fit-in/1200x0/filters%3Aformat%28jpg%29/https%3A%2F%2Fspecials-images.forbesimg.com%2Fimageserve%2F5d35eacaf1176b0008974b54%2F0x0.jpg%3FcropX1%3D790%26cropX2%3D5350%26cropY1%3D784%26cropY2%3D3349",
  },
  {
    name: "Vision",
    description: "Nuestra visión es convertirnos en el principal referente en la venta de automóviles, reconocidos por nuestra excelencia en el servicio al cliente.",
    image:
      "https://content2.kawasaki.com/ContentStorage/KMC/Products/8798/8c85b065-f4e9-4ee6-966f-2b7993daff08.png?w=767",
  },
  {
    name: "Conoce de nosotros",
    description: "En nuestra compañía, nos apasiona el mundo de los automóviles y queremos compartir esa pasión contigo.",
    image:
      "https://www.elcarrocolombiano.com/wp-content/uploads/2023/04/12-03-2023-PORTADA-Nissan-Skyline-R34-GT-R.jpg",
  },
  {
    name: "Contactanos",
    description: "This is the number for the contact about us 677 654890",
    image:
      "https://suenalanoticia.com/wp-content/uploads/2015/07/headerContactanos.jpg",

  },
];

export default vehicles;
